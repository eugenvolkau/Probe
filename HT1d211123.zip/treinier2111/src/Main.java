import java.util.Random;

public class Main {
    public static void main(String[] args) {
        float nearp = ddd();

        System.out.println("Hello world!" + nearp);
    }

    public static float ddd() {
        Random rn = new Random();

        float dist_1 = rn.nextFloat(9, 11);
        float dist_2 = rn.nextFloat(9, 11);
        System.out.println("First   :  " + dist_1);
        System.out.println("Second  :                   " + dist_2);
        float delta_1 = 10 - dist_1;
        float delta_2 = 10 - dist_2;
        System.out.println("First delta   :  " + delta_1);
        System.out.println("Second delta :                      " + delta_2);
        if (Math.abs(delta_1) > Math.abs(delta_2)) {
            if (delta_2 > 0) {
                System.out.println("Second forward  : " + delta_2);
            } else {
                System.out.println("Second rearward  : " + delta_2);
            }
        } else {
            if (delta_1 > 0) {
                System.out.println("Erst forward  : " + delta_1);
            } else System.out.println("Erst rearward  : " + delta_1);
        }


        return Math.abs(delta_1) > Math.abs(delta_2) ? delta_2 : delta_1;
        //(System.out.println("Second is nearby");


    }
}

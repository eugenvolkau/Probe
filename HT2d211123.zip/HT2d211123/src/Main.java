import java.util.Random;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Random rand = new Random();
        int num1 = rand.nextInt(1, 9);
        int num2 = rand.nextInt(1, 9);
        System.out.println("When  " + num1 + "  multiply by  " + num2 + "  will be equal = ?");
        int multPC = num1 * num2;
        Scanner sc = new Scanner(System.in);
        System.out.println("indicate the multiplier");
        int nUs1 = sc.nextByte();

        if (multPC == nUs1)
        {
            System.out.println("genius " + num1 + (" x ") + num2 + (" = ") + nUs1);
        }
        else
        {
            System.out.println("Stupid! It should be like this  :  " + multPC);
        }
    }


    }



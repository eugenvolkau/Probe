import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String str1;
        do {
            int n = getGCD();
            System.out.println("GCD  : " + n);
            System.out.println(" Продолжить программу?    Нет    Stop ");
            Scanner str = new Scanner(System.in);
            str1 = str.nextLine();
        }
        while (!str1.equalsIgnoreCase("Stop"));
    }

    private static int getGCD() {
        int a = getNum();
        int b = 2;
        do {
            int c = 0;
            double d;
            double h;
            b++;
            if (a % 2 == 0) {
                double g = a % 2;
                System.out.println(g + "  GCD    " + a / 2);
            } else {
                c = a / b;
                d = (double) a / b;
                h = c - d;
                if (h == 0) {
                    System.out.println("GCD  : " + c);
                    return c;
                }
            }
        } while (true);
    }
    private static int getNum() {
        System.out.println("Введите любое целое число");
        Scanner sc = new Scanner(System.in);
        int num = Math.abs(sc.nextInt());
        return num;
    }
}




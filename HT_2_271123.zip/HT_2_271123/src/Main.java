import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        System.out.println("Введите любое целое число");
                Scanner sc = new Scanner(System.in);
                long a = sc.nextLong();
        long b = 3;
        long c = 0;
        double d;
        double h;
String str = "1";
        if(a%2==0){
            double g = a%2;
            System.out.println( g +  "  GCD    " + a/2);}else {
            do {
                c = a / b;
                d = (double) a / b;
                h = c - d;
                b++;
                //System.out.println("Divider" + b);
                System.out.println(" Продолжить программу? Да  Пробел    Нет    Stop ");
    str = sc.nextLine();

            if(str.equalsIgnoreCase("Stop")&&h!=0) break;
        }
            while (h != 0);
            String stbrik = str.equalsIgnoreCase("Stop")?"Привет в шляпу":("GCD  : " + c);
            System.out.println(stbrik);
        }}

}






public class Main {
    public static void main(String[] args) {
        int beth = 57;
        int today = 23;
        System.out.println("Сколько лет?");
        System.out.println("Родился в 57 на дворе 23");
        System.out.printf("Если 57-23 =");
        System.out.println(beth - today);
        System.out.println("Как то так?");
    }
}
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Integer shifter = 2;
        Scanner scr = new Scanner(System.in);
        System.out.println("Введи целое число");
        Integer resu = scr.nextInt();
    Integer resu_1 = resu >> shifter;
    System.out.println(" result in binary  : " + Integer.toBinaryString(resu_1));
    }
}
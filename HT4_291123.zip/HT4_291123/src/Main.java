import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Random;
public class Main {
    public static void main(String[] args) {
        String[] stStr5 = new String[5];
        String str = "";
        int numstr = 0;
        String str1 = "";
        for (int j = 0; j < stStr5.length; j++) {
            stStr5[j] = getStr();
            int lenst = stStr5[j].length();
            System.out.printf("%d %s %2s %2s %d %n", j, " --->  ", stStr5[j], "  --->  ", lenst);
        }
        String maks = stStr5[0];
        int maxind = 0;
        for (int i = 1; i < stStr5.length; i++) {
            if (stStr5[i].length() > maks.length()){
                maks = stStr5[i];
                maxind = i;
            }
        }
       System.out.printf("%n%n%n%s%s  %d %s", maks, "   номер строки      -->  ", maxind, "     ");
    }
    public static String getStr() {
        Random rnd = new Random();
        int longStr = rnd.nextInt(0, 20);
        byte[] mass = new byte[longStr];
        new Random().nextBytes(mass);
        String genStr = new String(mass, Charset.defaultCharset());
        //System.out.println(genStr);
        return genStr;
    }
}
//Задание 4.
//Создайте массив из 5 строк. Используя метод length() строк, найдите
// строку с наибольшей длиной и строк
// с наименьшей длиной.
//Выведите массив и полученный строки в консоль.


import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        long sumDonat = 0;
        long sumTax = 0;
        int seaCatNeed = 1000100;
        long realSum = 0;
        for (int i = 0; i <= 1000000; ++i) {
            int apr = getDonat();
            float sttax = gettax();
            long taxOne = (long) (apr * sttax);
            sumTax = sumTax + taxOne;
            sumDonat = apr + sumDonat;
            realSum = sumDonat - sumTax;

            if (seaCatNeed <= realSum) {
                break;
            }
            {
                System.out.println("Всего удалось привлеч  :  " + sumDonat);
                System.out.println("Котикам достанется     :  " + (realSum));
                System.out.println("Котики на 2-х ногах заберут :  " + sumTax);
                System.out.println("Все котики делают глубокий выдох. Денег хватит всем!");

            }
        }
    }

    public static int getDonat() {
        Integer[] transf = {1, 5, 10, 100};
        int transf1 = transf[new Random().nextInt(4)];
        return transf1;
    }

    public static float gettax() {
        float tsxometer = (float) (0.05 + (Math.random() / 20));
        return tsxometer;
    }
}
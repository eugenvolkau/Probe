import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner scr =new Scanner(System.in);
            System.out.println("Mister Seller! Enter the purchase amount.");
        Float sumBye = scr.nextFloat();
            System.out.println("Mister Seller! Indicate how much the buyer contributed.");
        Float sumContr = scr.nextFloat();
        float change = sumContr - sumBye;
        int banknote = (int)change;
       //System.out.println((int)change);
        int coin = (int)((change - banknote) * 100);
        System.out.println("this can be returned to the buyer");
        System.out.println("Euro       " + "   cente");
        System.out.println(banknote + "    ---  " + coin);
        //System.out.println(sumBye);
    }
}
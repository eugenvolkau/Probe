import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
     double num1 = getNums();
     double num2 = getNums();
     double num3 = getNums();
     double num4 = getNums();
        System.out.println( + num1 + "*" + num2 + "*" + num3  + "*" + num4 + "=" + getMult(num1,num2,num3,num4));
    }
    private static double getMult (double num3,double num1, double num2,double num4) {
       return  num4 * getMult(num1,num2,num3);
    }
    private static double getMult(double num3,double num1, double num2) {
       return  num3 * getMult(num1,num2);
           }
    private static double getMult(double num1, double num2){
        return num1*num2;
    }
    private static double getNums() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Insert any nummer Pls  ");
        if (sc.hasNextDouble()) {
            return sc.nextDouble();
        } else getNums();
        return getNums();
    }
}
//Задание 1.
//Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
//В методе умножения 3-х чисел
// используйте вызов метода для 2-х чисел. В методе умножения 4-х чисел
// – вызов метода для 3-х чисел.
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        String[] weDay = {"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        Scanner sc =new Scanner(System.in);
       System.out.println("indicate the day of the week");
       byte i = sc.nextByte();
        String str  = i<=7 ? weDay[--i] : "incorrect";
        System.out.println("you choosed  :  " + str
        );
    }
}
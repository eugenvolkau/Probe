import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("now there will be arithmetic!");
        Scanner scr = new Scanner(System.in);
        System.out.println("Please enter the first number");
        int nuOne = scr.nextInt();
        System.out.println("Please enter the second number");
        int nuTwo = scr.nextInt();
        System.out.println("now let's select an action");
        System.out.println("+     -- Enter 1   ");
        System.out.println("-     -- Enter 2   ");
        System.out.println("*     -- Enter 3   ");
        System.out.println("/     -- Enter 4   ");
        int nuTree = scr.nextInt();
        switch (nuTree) {
            case 1:
                int sUma = nuOne + nuTwo;
                System.out.printf("Сложили  :  %d %n", sUma);
            case 2:
                int taW = nuOne - nuTwo;
                System.out.printf("Отняли  :   %d %n", taW);
            case 3:
                int mUlt = nuOne * nuTwo;
                System.out.printf("Помножили  :  %d %n", mUlt);
            case 4:
                int dIv = nuOne / nuTwo;
                System.out.printf("Поделили поровну  :   %d %n", dIv);
        }
    }
}
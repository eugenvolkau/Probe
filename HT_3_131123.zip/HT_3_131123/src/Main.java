import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("now there will be arithmetic!");
        Scanner scr = new Scanner(System.in);
        System.out.println("Please enter the first number");
        float nuOne = scr.nextFloat();
        System.out.println("Please enter the second number");
        float nuTwo = scr.nextFloat();
        System.out.println("now let's select an action");
        System.out.println("+     -- Enter 1   ");
        System.out.println("-     -- Enter 2   ");
        System.out.println("*     -- Enter 3   ");
        System.out.println("/     -- Enter 4   ");
        int nuTree = scr.nextInt();
        switch (nuTree) {
            case 1:
                float sUma = nuOne + nuTwo;
                System.out.printf("Сложили  :  %s %n", sUma);break;
            case 2:
                float taW = nuOne - nuTwo;
                System.out.printf("Отняли  :   %s %n", taW);break;
            case 3:
                float mUlt = nuOne * nuTwo;
                System.out.printf("Помножили  :  %s %n", mUlt);break;
            case 4:
               float dIv = nuOne/nuTwo;
                System.out.printf("Поделили поровну  :   %s %n", dIv);break;
        }
    }
}

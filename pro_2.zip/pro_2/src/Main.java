import java.util.Formatter;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.
        String morgen_1 = "Доброе";
        String morgen_2 = "утро";
        String morgen_3 = "страна";
        System.out.println(morgen_1+ " " + morgen_2  + " " + morgen_3 +"?");
        Scanner scanner_1 = new Scanner(System.in);
        System.out.println("Сделайте выбор, Y- да, N - нет");
        String antwort_1  = scanner_1.next();

        String gil = "n";

        if (antwort_1.equals("Y"))
        {
            Formatter formatter = new Formatter();
            formatter.format("%s %s %s!", morgen_1, morgen_2, morgen_3);
            System.out.println(formatter);
        }
        {
            if (antwort_1.equals("N"))
            {

                System.out.println("Вам пора на Майорку");
            }else
            {

            }
        }

        for (int i = 1; i <= 5; i++)
        {
            System.out.println("i = " + i);
        }
    }
}
import tracPark.TracManuf;
import tracPark.TracModel;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {

 TracModel fendt = new TracModel();
        fendt.model = "FENDT 1050";
        fendt.yearManuf = LocalDate.of(2022, 12, 24);
        fendt.tracManuf = TracManuf.FENDT;
        fendt.setEnginModel("GTR347-5FR");
        fendt.setGearBoxMod("GB8/4LSf");
        fendt.tractiveEeffort = 5500;
        fendt.tankcap = 167;
        fendt.weight = 5200;
        fendt.serialNum = "#00000000013";
        fendt.setPrice(34900);
fendt.setContractN("TrGetN20231113_22");

        System.out.println("-----------------FENDT-------------------");
        System.out.println("Model  :  " + fendt.model);
        System.out.println("Manufacture year :  " + fendt.yearManuf);
        System.out.println("Manufacturer   :  " + fendt.tracManuf);
        System.out.println("Engine model  :   " + fendt.getEnginModel());
        System.out.println("GearBox model  :   " + fendt.getGearBoxMod());
        System.out.println("tractive effort  ,kgf  :  " + fendt.tractiveEeffort);
        System.out.println("Tank capacity ,l :  " + fendt.tankcap);
        System.out.println("Weight ,kg  :  " + fendt.weight);
        System.out.println("Serial number   :  " + fendt.serialNum);
        System.out.println("Price ,$  :   " + fendt.getPrice());
        System.out.println("Contract Number   :  " + fendt.getContractN());
        System.out.println("------------JOHN DEER---------------");

  TracModel johnDeer = new TracModel();
        johnDeer.model = "6095B";
        johnDeer.yearManuf = LocalDate.of(2021, 5, 23);
        johnDeer.tracManuf = TracManuf.JOHNDEER;
        johnDeer.setEnginModel("JDHD340SF");
        johnDeer.setGearBoxMod("GD6/8/345AA");
        johnDeer.tractiveEeffort = 6400;
        johnDeer.tankcap = 95;
        johnDeer.weight = 2500;
        johnDeer.serialNum ="JD-12SA21233378952";
        johnDeer.setPrice(17800);
        johnDeer.setContractN("#230620230612");


//johnDeer.
        System.out.println("Model  :  " + johnDeer.model);
        System.out.println("Manufacture year :  " + johnDeer.yearManuf);
        System.out.println("Manufacturer   :  " + johnDeer.tracManuf);
        System.out.println("Engine model  :   " + johnDeer.getEnginModel());
        System.out.println("GearBox model  :   " + johnDeer.getGearBoxMod());
        System.out.println("tractive effort  ,kgf  :   " + johnDeer.tractiveEeffort);
        System.out.println("Tank capacity ,l :  " + johnDeer.tankcap);
        System.out.println("Weight ,kg  :  " + johnDeer.weight);
        System.out.println("Serial number   :  " + johnDeer.serialNum);
        System.out.println("Price ,$   :  " + johnDeer.getPrice());
        System.out.println("Contract Number  :  " + johnDeer.getContractN());
        System.out.println("----------------Calligraphy test-----------------------");
 TracModel cloned = new TracModel(fendt);
System.out.println(cloned==fendt);
        System.out.println(fendt.getModel().equals(cloned.getModel()));
        System.out.println(fendt.getSerialNum().equals(cloned.getSerialNum()));

    }
}
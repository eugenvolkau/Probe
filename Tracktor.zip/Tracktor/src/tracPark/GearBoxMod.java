package tracPark;

import java.time.LocalDate;

public class GearBoxMod {
    public  String gBMod;
    GearBoxManuf gearBoxManuf = GearBoxManuf.UNKNOWN;
    public long maxTorque;
    private long weight;
    public long maxRotatfreq;
    LocalDate yearManuf;
    private String SerialNum;
}

package tracPark;

import java.time.LocalDate;

public class TracModel {
    public String model;
    public LocalDate yearManuf;
    public TracManuf tracManuf = TracManuf.UNKNOWN;
    public long tankcap;
    public float tractiveEeffort;
    public long weight;
    private long price;
    public String serialNum;

    private String engMod;
    private String gBMod;
    private String contractN;

    public TracModel() {

    }


    public Object getEnginModel() {
        return engMod;
    }

    public String getModel() {
        return model;
    }
    //original.yearManuf,original.tracManuf,original.weight,original.tankcap,original.tractiveEeffort
    public TracModel(TracModel original){
        this.tractiveEeffort=original.tractiveEeffort;
        this.tracManuf=original.tracManuf;
        this.yearManuf=original.yearManuf;
        this.weight=original.weight;
        this.tankcap=original.tankcap;
        this.price=original.price;
        this.serialNum=original.serialNum;
        this.model=original.model;
            }
    public String getSerialNum() {
        return serialNum;
    }

    public void setEnginModel(String engMod) {
        if (engMod==null || engMod.isBlank()) throw new IllegalArgumentException("The engMod can't be empty");
                this.engMod = engMod;
    }
    public long getPrice() {
        return price;
    }
    public void setPrice(long price) {
        if (0>price) throw new IllegalArgumentException("The price  must be positive");
        this.price=price;
}
    public Object getGearBoxMod() {
           return gBMod;
    }
    public void setGearBoxMod(String gBMod) {if (gBMod==null || gBMod.isBlank()) throw new IllegalArgumentException("The gBMod can't be empty");
        this.gBMod = gBMod;
    }
    public String getContractN() {
        return contractN;
    }
    public void setContractN(String contractN) {
        if (contractN==null || contractN.isBlank()) throw new IllegalArgumentException("The contractN can't be empty");
        this.contractN = contractN;
    }
}
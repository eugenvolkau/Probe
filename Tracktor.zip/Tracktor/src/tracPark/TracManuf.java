package tracPark;

public enum TracManuf {
    JOHNDEER,
    FENDT,
    NEWHOLLAND,
    CASE,
    CLAAS,
    CATERPILL,
    DEUTZFAHR,
    UNKNOWN

    }

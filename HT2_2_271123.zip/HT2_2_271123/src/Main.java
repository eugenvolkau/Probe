import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //String str = "";
        long j = 1;
        Scanner sc = new Scanner(System.in);
        String str;
        do {
            System.out.println("Сума" + getSumm());
            System.out.println("Будем дальше калькулировать?");
            System.out.println("Досыть    жмем  :    quit");
            str = sc.nextLine();
        }
        while (!str.equalsIgnoreCase("quit"));
    }
private static long getNummer()
{  Scanner sc = new Scanner(System.in);
    long a1 = sc.nextLong();
    return a1;

}
private static long getSumm(){
    System.out.println("Введите любое целое число");
    long a = getNummer();
    System.out.println("Введите любое целое число");
    long b = getNummer();
    long d;
    long c;
    long itogo = 0;
    if (a > b) {
        d = a;
        c = b % 2 != 0 ? ++b : b;
    } else {
        d = b;
        c = a % 2 != 0 ? ++a : a;

    d = d % 2 != 0 ? --d : d;}

    for (long i = 0; i <= (d - c) / 2; i++) {
        itogo = itogo + (c + i * 2);
    }
    System.out.println("Сума" + itogo);
    return itogo;
    }
}


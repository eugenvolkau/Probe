import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String str = "";
        long j = 1;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Введите любое целое число");
            long a = sc.nextLong();
            System.out.println("Введите любое целое число");
            Scanner sc1 = new Scanner(System.in);
            long b = sc1.nextLong();
            long d;
            long c;
            if (a > b) {
                d = a;
                c = b % 2 != 0 ? ++b : b;
            } else {
                d = b;
                c = a % 2 != 0 ? ++a : a;
            }
            d = d % 2 != 0 ? --d : d;
            long itogo = 0;
            for (long i = 0; i <= (d - c) / 2; i++) {
                itogo = itogo + (c + i * 2);
            }
            System.out.println("Сума" + itogo);
            System.out.println("Будем дальше калькулировать?");
            System.out.println("Досыть    жмем  :    quit");
            str = sc.nextLine();
            j++;
        }
        while (!str.equalsIgnoreCase("quit") || j <= 0);
    }
}
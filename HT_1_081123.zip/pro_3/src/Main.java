//import static jdk.vm.ci.meta.JavaKind.Char;

public class Main {
    public static void main(String[] args)
    {
          Character char_1 = 'G';
            Integer   menge = 89;
            Byte     Klein = 4;
            Short   kurz = 56;
            Double duschwemm = 4.7333436;
            Double duschwemm_1 = 4.355453532;
            Integer longz = 12121;
        System.out.println("Hello world!");
            System.out.println("VAR. char_1 :" + char_1);
            System.out.println("VAR. Integer :" + menge);
            System.out.println("VAR. Byte :" + Klein);
            System.out.println("VAR. Short  :" + kurz);
            System.out.println("VAR. Double  :" + duschwemm);
            System.out.println("VAR. Double  :" + duschwemm_1);
            System.out.println("VAR. Integer  :" + longz);
    }
}
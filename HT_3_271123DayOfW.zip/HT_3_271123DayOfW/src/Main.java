import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
    Scanner sc = new Scanner(System.in);
        System.out.println(Arrays.toString(DayOfWeek.values()));
        System.out.println("Введите свой любимый день");
    String yourTag = sc.nextLine();
    DayOfWeek tagYour = DayOfWeek.valueOf(yourTag.toUpperCase());
        System.out.println("Как интересно! Ваш любимый день  " + tagYour);
       int a = DayOfWeek.valueOf(yourTag.toUpperCase()).ordinal();
        String strok1 = Arrays.toString(DayOfWeek.values());
        String strok2 = strok1.replaceAll(yourTag.trim().toUpperCase(),"");
        strok1 = strok2.trim().replace(", ",",").replace(",,",",");
        System.out.println("Вот так всегда   " + strok1);

    }
}
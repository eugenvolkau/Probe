

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Enter number from  1 to 100");
        System.out.println(getStr());
    }
    private   static int getNum() {
        Scanner scn = new Scanner(System.in);
       //&&(1<scn.nextInt()&&100>scn.nextInt())
        if (scn.hasNextInt()){
         return scn.nextInt();}

        else {
            System.out.println("Enter number from  1 to 100");
            return getNum();
        }
    }
    private static StringBuilder getStr() {
        int num1 = getNum()+1;
       if(0>num1|| num1>=100)
         System.out.println((num1-1) + "    the numbers are unrealistic");
        Scanner sc = null;
        try {
            sc = new Scanner(new File("C:\\Users\\eugen\\Scool\\HTask\\Ubiley\\weddingAn.txt"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        List<String> lines = new ArrayList<>();
        while (sc.hasNextLine()) {
            lines.add(sc.nextLine());
        }
        String[] arr = lines.toArray(new String[lines.size()]);
        int a = arr.length;
        StringBuilder subNum1 = new StringBuilder(String.valueOf(num1));
        subNum1.insert(0, " ");
        subNum1.insert(subNum1.length(), " ");
        //System.out.println(subNum1);
                String congratul = num1 == 13 ? " 14 " : num1 == 54 ? " 55 " : (num1 >=0) && (num1 < 70) ? String.valueOf(subNum1) : (num1 > 70) && (num1 < 75)
                ? " 75 " : (num1 > 75) && (num1 < 80) ? " 80 " : (num1 > 80) && (num1 < 85) ? " 85 " : (num1 > 85) && (num1 < 90) ? " 90 " : (num1 > 90) && (num1 < 95) ? " 95 "
                : num1 > 95 && num1 < 100 ? " 100 " : null;
        StringBuilder subNum2 = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (0<=arr[i].indexOf(congratul)) {
                System.out.println(arr[i].indexOf(congratul));
                subNum2.append(arr[i]);
                return subNum2;
            }
        }
        System.out.println(subNum1);
        return subNum1;

    }
}

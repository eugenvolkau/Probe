import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

import kasino.RPS;

public class Main {
    public static void main(String[] args) {
        RPS[] b1 = RPS.values();
        Byte x = 0 ;
        int z = 0;
        int stud = 0;
        int prof = 0;
        int paritet = 0;
        while (x != 1)
        {
            System.out.println("общий счётчик партий   " + z++);
            System.out.println("Студент победил!   " + stud + "  Раз");
            System.out.println("опыт победил!      " + prof + "  Раз");
            System.out.println("Ничьих             " + paritet + "  Раз");
            System.out.println(Arrays.toString(RPS.values()));
            byte abc = getAbc();
            RPS apprentice = b1[abc];
            Random rn = new Random();
            int a = rn.nextInt(3);
            RPS sharper = b1[a];
            System.out.println("sharper  :  " + sharper + "   apprentice  :   " + apprentice);
            String winnegreit = (apprentice == sharper) ? "Победила дружба" :
                    (apprentice == b1[2] && sharper == b1[1]) || (apprentice == b1[1] && sharper == b1[0]) ||
                            (apprentice == b1[0] && sharper == b1[2]) ? "Студент победил!;" :
                            "Победу празднует опыт!";
            if (winnegreit == "Студент победил!;") stud++;
            if (winnegreit == "Победу празднует опыт!")
            {prof++;}
            else
            {paritet++;}
            System.out.println(winnegreit);
            Scanner sc2 = new Scanner(System.in);
            System.out.println("Ещё партейку?   yes! жми 0     no  жми   1");
            x = sc2.nextByte();
            //if(x=="n") break;
            System.out.println(x);

        }

    }

    public static Byte getAbc() {
        System.out.println("Сделайте Вашу ставку!");
        System.out.println("Из этого разнообразия введите пальцем по клаве 0  1  2   ");
        Scanner scs = new Scanner(System.in);
        if (scs.hasNextByte()) {
            return scs.nextByte();
        } else {
            System.out.println("Учимся постепенно давить на клаву");
            return getAbc();
        }
    }
}


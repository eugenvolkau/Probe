
import java.util.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        int num;
        int[] klad = new int[8];
        Random rnd = new Random();
        for (num = 0; num < klad.length; num++) {
            klad[num] = rnd.nextInt(50);
            System.out.printf("%s%d%s", "  ", klad[num], "  ");
        }
        System.out.println("");
        for (num = 0; num < klad.length; num++) {
            if (num % 2 != 0) {
                klad[num] = 0;
            } else {
                klad[num] = klad[num];
            }
            System.out.printf(" %d %s ", klad[num], " ");
        }
        System.out.println(Arrays.toString(klad));
        Arrays.sort(klad);
        for (int i = 0; i < klad.length; i++) {
            System.out.printf(" %d %s ", klad[i], " ");
        }
    }
}

//Задание 3.
//Создайте массив из 8 случайных целых чисел из интервала [1;50]
//Выведите массив в консоль в строку.
//Замените каждый элемент с нечетным индексом на ноль.
//Снова выведете массив в консоль в отдельной строке.
//Отсортируйте массив по возрастанию.
//Снова выведете массив в консоль в отдельной строке.


import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
            throws Exception
    {
        Scanner scUs = new Scanner(System.in);
        System.out.println("Уважаемый(ая) сколько уже лет Вы на семейном фронте?");
        String i = scUs.nextLine();
        System.out.println(i);
        File fil = new File("C:\\Users\\eugen\\Scool\\HTask\\Java\\weddingAn.txt");
        FileReader fr = new FileReader(fil);
        Scanner sc = new Scanner(fr);
        System.out.println(sc);
        int lng = Integer.parseInt(i);
        if (1 > lng) {
            System.out.println("Дорогуша! приходите позже. Вам надо подрасти");
            sc = null;
        }
        if (99 <= lng) {
            System.out.println("Уважаемый! Не морочте мне голову. Нормальные люди столько не живут!");
        sc = null;
        }
        String ustr = Integer.toString(lng);
        while (sc.hasNextLine()) {
            String stro = (sc.nextLine().substring(0,3));
            String[] str = stro.split((" "));
            int a = Integer.parseInt(str[0]);
            int b = Integer.parseInt(i);
            if (b<(a+1)) {
                System.out.println("Боже мой! Ваш ближайший юбилей : " + sc.nextLine());
                System.out.println("    Наше Вам не хворать");
                fr.close();
                break;
            }
        }
        fr.close();
    }
}
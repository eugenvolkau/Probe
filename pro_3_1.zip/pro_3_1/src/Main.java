public class Main {
    public static void main(String[] args)
    {
        Integer itoe = 345;
        Integer jtoe = 987;
        System.out.printf("%d -> %d, %d, %d %n", itoe, ((itoe/100)%10), ((itoe/10)%(10)), ((itoe%100)%10));
        System.out.printf("%d -> %d, %d, %d %n", jtoe, ((jtoe/100)%10), ((jtoe/10)%(10)),((jtoe%100)%10));
    }
}
import java.util.Arrays;

public class Main {
    // №2. Двумерные массивы Создайте двумерный массив и заполните его
    // заглавными буквами русского алфавита. Буква Ё должна быть на своём
    // месте.
    public static void main(String[] args) {
        char[] cyrill = new char[33];
        for (int i = 0; i < cyrill.length; i++) {
            cyrill[i] = (char) ('А' + i);
            System.out.println(cyrill[i]);
        }
        for (int i = 32; i > 6; i--) {
            cyrill[i] = cyrill[i - 1];
        }
        int b = 0;
        cyrill[6] = 'Ё';
        System.out.println(Arrays.toString(cyrill));
        char[][] GreatCyr = new char[3][11];
        for (int i = 0; i < GreatCyr.length; i++) {
            for (int j = 0; j < GreatCyr[i].length; j++) {
                GreatCyr[i][j] = (char) cyrill[b++];
            }
        }
        for (int i = 0; i < GreatCyr.length; i++) {
            System.out.println(" ");
            for (int j = 0; j < GreatCyr[i].length; j++) {
                System.out.printf("%2S", GreatCyr[i][j]);
            }
        }
    }
}


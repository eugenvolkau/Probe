import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner scr = new Scanner(System.in);
        System.out.println("You are an architect. Indicate how high (in meters)");
        System.out.println(" the palace you propose to build");
        Float length = scr.nextFloat();
        System.out.println("Indicate the remoteness from the palace to the capital in km.");
        Integer remte = scr.nextInt();
        System.out.println("Transfer innformation in St. Petersburg  --- press 1");
        System.out.println("Transfer innformation in London          --- press 2");
        Scanner scr_1 = new Scanner(System.in);
        Short chois = scr_1.nextShort();
        switch (chois) {
            case 1:
                double length_Arsh = length / 0.7112;
                int lad = (int) length_Arsh;
                double lad_1 = length_Arsh - lad;
                Integer remte_1 = (int) (remte / 1.0668);
                if (lad_1 > (0.075 / 0.7112)) {
                    int lad_2 = (int) (lad_1 * 0.7112 / 0.075);
                    System.out.println("Высота дворца " + lad + "  аршин  и  " + lad_2 + "  ладони");
                    System.out.println("удаленность от столицы " + remte_1 + "  Верст");
                } else {
                    System.out.println("Высота дворца " + lad + "  аршин ");
                    System.out.println("удаленность от столицы " + remte_1 + "Верст");
                }
                ;
                break;
            case 2:
                double length_ft = length / 0.3048;
                int lad_m = (int) length_ft;
                double lad_1m = length_ft - lad_m;
                //System.out.println(lad_1m + " " + lad_m + " " + length_ft );
                int remte_ml = (int) (remte / 1.6093);
                if (lad_1m > (0.0847)) {
                    int lad_2 = (int) (lad_1m * 12);
                    System.out.println("Вheight of the palace " + lad_m + "  ft  и  " + lad_2 + "  inch");
                    System.out.println("distance from the capital    :  " + remte_ml + "  mi");
                } else {
                    System.out.println("Вheight of the palace " + length_ft);
                    System.out.println("distance from the capital    :  " + remte_ml + "  mi");
                }
                break;
        }

       // System.out.println("Hello world!");
    }
}
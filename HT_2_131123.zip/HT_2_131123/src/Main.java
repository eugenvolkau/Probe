import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        System.out.println("Hello world!");
    Scanner introduce = new Scanner(System.in);
    System.out.print("What is your name ?");
    String antwort_1 = introduce.next();

    System.out.println("How old are you?");
    Byte antwort_2 = introduce.nextByte();
    Byte Age = antwort_2;
            System.out.println("Your weight ?");
    Float antwort_3 = introduce.nextFloat();
    Float weght = antwort_3;
            System.out.println("Deeply Dear " + antwort_1 + "!");
            System.out.println("At " + Age + " years old, you are as dear to us as " +
                    "" + weght + " kilograms of gold. ");
}}
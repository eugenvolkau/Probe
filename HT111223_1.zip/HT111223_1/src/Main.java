import java.util.Scanner;
// 1 уровень сложности: Задание 1. Введите 2 слова, воспользуйтесь сканером, состоящие из четного
// количества букв (проверьте количество букв в слове).
//Нужно получить слово, состоящее из первой половины первого слова и второй половины второго
// слова. распечатать на консоль. Например: ввод - mama, papa. Вывод – mapa
public class Main {
    public static void main(String[] args) {
        System.out.println("Enter your Word pls. The word must contain an even number of letters.:  ");
        String st1 = getWord();
        String st2 = getWord();
        int leng1 = (int) st1.length();
        int leng2 = (int) st2.length();
        StringBuilder st11 = new StringBuilder(st1);
        StringBuilder st21 = new StringBuilder(st2);
        st21.replace(0,leng2/2,st11.substring(0,leng1/2));
        System.out.println("It war :  " + st1 + "  " + st2 + "    It is  :  " + st21);
    }
    private static String getWord(){
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
            if(str.length()%2!=0){
                System.out.println("Attention! The word must contain an even number of letters.");
                return getWord();}
     return str;
    }
}
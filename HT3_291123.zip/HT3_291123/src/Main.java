import java.util.*;

import static java.util.Collections.*;

public class Main {
    public static void main(String[] args) {
        //int b = 5;
int num ;
        int[] klad = new int[8];
        Random rnd = new Random();
        for (num = 0; num < klad.length; num++) {
            klad[num] = rnd.nextInt(50);
        System.out.printf("%s%d%s","  " , klad[num], "  ");}
        System.out.println("");;
        //Arrays.sort(klad);
        //System.out.println(Arrays.toString(klad));
        //System.out.printf("%s %2d %s", " ", klad[num], " ");
    for (num = 0; num <= klad.length; num++) {
         if (num % 2 != 0)
          {klad[num] = 0;}else {
            klad[num] = klad[num];}
           System.out.printf(" %d %s ", klad[num], " ");}
        System.out.println(Arrays.toString(klad));}
    //Arrays.sort(klad);
      //  System.out.println(Arrays.(klad));
              //System.out.printf(" %2d %s", member, " ");
        }
        //System.out.println("");;
        //Arrays.sort(klad);


        //System.out.println("    hhhhhh");
        //      System.out.println(klad[1]);  System.out.println(klad[2]);        System.out.println(klad[3]);
       // System.out.println(klad[4]);        System.out.println(klad[5]);        System.out.println(klad[6]);        System.out.println(klad[7]);
        //for (int member : klad) {

        //    System.out.printf(" %2d %s", member, " ");


    //private static void sort(int i) {


    //}
           // for (int i = 0; i < klad.length ; i++) {
            //    System.out.printf("%2d %s", klad, " ");
           // }
            //}
            //for (int num : klad) {
            // System.out.println(num);
            //}
            //int num1 = klad.length;
            //Collections.sort(klad);
            //klad[i] = getMass(klad,  num1);
            //System.out.println("After Sorting:");
            //for (int num1 : klad) {
            //    System.out.println(num);
             //   System.out.printf("%s %2d", " ", klad[num]);
           // }
        // }
        //for (int i = 0; i < 8; i++) {
        //System.out.println("nummer : " + );

        //private static int getMass ( int[] klad, int num){
        ///if (num < klad.length) {
//getMass(klad, num -1);
 //               System.out.print(klad[num] + "  ");

//Задание 3.
//Создайте массив из 8 случайных целых чисел из интервала [1;50]
//Выведите массив в консоль в строку.
//Замените каждый элемент с нечетным индексом на ноль.
//Снова выведете массив в консоль в отдельной строке.
//Отсортируйте массив по возрастанию.
//Снова выведете массив в консоль в отдельной строке.

        //System.out.println("Hello world!");
//import java.util.Arrays;
//import java.util.Random;
//
//class Main
//{
//	private static final int len = 10000000;
//
//	public static void main(String[] args)
//	{
//		// create two arrays of integers of size 10 million
//		int[] arr1 = new int[len];
//		int[] arr2 = new int[len];
//
//		// Assign random values to `arr1[]` and `arr2[]`
//		Random r = new Random();
//		for (int i = 0; i < len; i++)
//		{
//			arr1[i] = r.nextInt();
//			arr2[i] = arr1[i];
//		}
//
//		long start = System.currentTimeMillis();
//
//		// sort `arr1[]` using `Arrays.sort()`
//		Arrays.sort(arr1);
//
//		long end = System.currentTimeMillis();
//
//		System.out.println("Arrays.sort() took " + (end - start) + " ms");
//
//
//		start = System.currentTimeMillis();
//
//		// sort `arr2[]` using `Arrays.parallelSort()`
//		Arrays.parallelSort(arr2);
//
//		end = System.currentTimeMillis();
//
//		System.out.println("Arrays.parallelSort() took " +
//								(end - start) + " ms");
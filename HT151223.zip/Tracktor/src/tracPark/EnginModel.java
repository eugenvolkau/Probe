package tracPark;

import java.time.LocalDate;

public class EnginModel {
    private String engMod;
    public EnginManuf enginManuf = EnginManuf.UNKNOWN;
    public long power;
    public long maxTorque;
    private long weight;
    public long maxRotatfreq;
    LocalDate yearManuf;
    private String SerialNum;
}

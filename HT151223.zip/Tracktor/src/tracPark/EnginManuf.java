package tracPark;

public enum EnginManuf {
    PERKINS,
    VOLVO,
    CUMMINS,
    MITSUBISHI,
    IVECO,
    MAN,
    DEUTZ,
    UNKNOWN
}

package tracPark;



public class ConsumTrac {
    private String name;
    private String getCntactPers;
    private String cntactPers;
    private String emailadr;
    private String contractN;

    public ConsumTrac() {
    }
}



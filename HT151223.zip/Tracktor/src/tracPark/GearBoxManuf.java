package tracPark;

public enum GearBoxManuf {
    SCHNEIDER,
    EATON,
    EMERSON,
    DANA,
    SUMITOMO,
    BONFIGLIOLI,
    ZF,
    UNKNOWN
}

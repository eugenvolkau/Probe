import java.util.Arrays;
import java.util.Scanner;

public class Main {
    //Задание 3. Задание из собеседования Яндекс:
    //дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов
    // латинского алфавита. Напишите метод, который «свернёт» строку к
    // виду A4B3C3D2EG, т.е. количество букв записывается цифрой. Если буква
    // одна, то цифра не ставится.
    public static void main(String[] args) {
        String str ="rrrrJJJJJ444444JJJJJJJJJkKKKKKKKKKKKKh";
        char[] ch = str.toCharArray();
        char current = ch[0];
        int count = 1;
        StringBuilder sb = new StringBuilder();
        String str1 = "";
            for (int i = 1; i < ch.length; i++) {
            if (ch[i]==current)
                count++;
            else {
                sb.append(str1=(count==1)?"":(String.valueOf(count))).append(current);
                count=1;
                current = ch[i];

            }

        }
        sb.append(str1=(count==1)?"":(String.valueOf(count))).append(current);
        System.out.println(sb);
    }
}
import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        System.out.println("Какое расстояние от Вашего дома до рабочего места в км  : ");
        float l1 = getAbc();
        System.out.println("Какое расстояние от рабочего места до магазина в км  : ");
        float l2 = getAbc();
        System.out.println("Какое расстояние от магазина до Вашего дома в км  : ");
        float l3 = getAbc();
        String str = (l1==l2 && l1==l3)?"Равносторонний":((l1==l2)||(l1==l3))||((l1==l3)||(l2==l3))?"Равнобедренный":"Неправильный";


        System.out.println("Ваша повседневная жизнь представляет собой " + str + "  Треугольник");
    }

    public static Float getAbc() {

        Scanner scs = new Scanner(System.in);
        if (scs.hasNextFloat()) {
            return scs.nextFloat();
        } else {
            System.out.println("Учимся постепенно давить на клаву");
            return getAbc();
        }
    }
}
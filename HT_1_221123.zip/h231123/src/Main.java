import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
            throws Exception {
        Scanner scUs = new Scanner(System.in);
        System.out.println("Уважаемый(ая) сколько уже лет Вы на семейном фронте?");
        File fil = new File("C:\\Users\\eugen\\Scool\\HTask\\Java\\weddingAn.txt");
        int i = scUs.nextInt();
        FileReader fr = new FileReader(fil);
        Scanner sc = new Scanner(fr);
        int j = i;
        if (1 > i) {
            System.out.println("Дорогуша! приходите позже. Вам надо подрасти");
        }
        if (i > 100) {
            System.out.println("Уважаемый! Не морочте мне голову. Люди столько не живут!");
        }
        String ustr = Integer.toString(i);
        while (sc.hasNextLine()) {
            String str = sc.nextLine();
            if (str.substring(0, 2).equals(ustr)) {
                System.out.println("Боже мой! Ваш ближайший юбилей : " + sc.nextLine());
                System.out.println("    Наше Вам не хворать");
                j++;
                fr.close();
                break;
            }
        }
        fr.close();
    }
}
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int[] stId = new int[5];
        System.out.println(Arrays.toString(getDateSet()));
        System.out.println("select a field to sort");
        System.out.println("DAYS press       1");
        System.out.println("MONTHS press     2");
        System.out.println("YEARS press      3");
        getFieldSortSelect(stId);
        String[] datsetwork = getDateSet();
        int num = Integer.parseInt(datsetwork[0].substring(stId[0], stId[1]));
        for (int i = 0; i < datsetwork.length - 1; i++) {
            int iDmax = i;
            for (int j = i + 1; j < datsetwork.length; j++) {
                int q = Integer.parseInt(datsetwork[j].substring(stId[0], stId[1]));
                if (q > Integer.parseInt(datsetwork[iDmax].substring(stId[0], stId[1])))
                    iDmax = j;
            }
            if (iDmax != i) {
                String zeitlich = datsetwork[i];
                datsetwork[i] = datsetwork[iDmax];
                datsetwork[iDmax] = zeitlich;
            }
        }
        System.out.println("  after sorting  ");
        for (int i = 0; i < datsetwork.length; i++) {
            System.out.println(datsetwork[i]);

        }System.out.printf("%s%n %s%n","Dear user! If you need to sort in the opposite direction,"
                ," rotate the token > in the line 22. Well-wisher.");
    }

    private static String[] getDateSet() {
        Random rnd = new Random();
        String[] dateSet = new String[8];
        System.out.println("  without sorting  ");
        for (int i = 0; i < 8; i++) {
            int year = rnd.nextInt(1900, 2024);
            int month = rnd.nextInt(1, 12);
            int day = rnd.nextInt(1, 30);
            LocalDate localDate = LocalDate.of(year, month, day);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            dateSet[i] = localDate.format(formatter);
            System.out.println(dateSet[i]);
        }
        return dateSet;
    }

    private static int[] getFieldSortSelect(int[] stId) {
        Scanner sc = new Scanner(System.in);
        stId[0] = 4;
        stId[1] = 4;
        if (!sc.hasNextInt()) {
            System.out.println("wrong choice made");
            return getFieldSortSelect(null);
        }
        int sel = sc.nextByte();
        switch (sel) {
            case 1: {
                stId[0] = 0;
                stId[1] = 2;
            }
            break;
            case 2: {
                stId[0] = 3;
                stId[1] = 5;
            }
            break;
            case 3: {
                stId[0] = 6;
                stId[1] = 10;
            }
            break;
        }
        return stId;
    }
}

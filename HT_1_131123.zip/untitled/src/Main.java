import java.util.Locale;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        boolean danet = rnd.nextBoolean();
        short kurzNum = (short) rnd.nextInt(32767, 32769);
        Integer normNum = rnd.nextInt(2147483646, 2147483647);
        Long LoNum = rnd.nextLong();
        Float schwimPoint = rnd.nextFloat(2, 3);
        double Duplet = rnd.nextDouble(1, 2);
        char symbol = (char) rnd.nextInt(57, 61);
        byte pobite = (byte) rnd.nextInt(25, 35);
            String degenerate = String.valueOf("  Boolen     :" + danet);
                String degenerate_1 = String.valueOf("     Short     :" + kurzNum);
        String degenerate_2 = String.valueOf("    Integer   :" + normNum);
            String degenerate_3 = String.valueOf("   long   :" + LoNum);
                String degenerate_4 = String.valueOf("    Float     :" + schwimPoint);
        String degenerate_5 = String.valueOf("    Double :" + Duplet);
            String degenerate_6 = String.valueOf("   character :" + symbol);
                String degenerate_7 = String.valueOf("   byte      :" + pobite);
        System.out.println( degenerate + degenerate_1 + degenerate_2 + degenerate_3 + degenerate_4 + degenerate_5 + degenerate_6 + degenerate_7);
            System.out.println(degenerate_1);
        System.out.println(degenerate_2);
            System.out.print(degenerate_3);
        System.out.println(degenerate_4);
            System.out.println(degenerate_5);
        System.out.println(degenerate_6);
            System.out.println(degenerate_7);
            for (int i = 0; i < pobite;  i++)
        {   char symbol_1 = (char) rnd.nextInt(1, 56);
            String degenerate_8 = String.valueOf(symbol_1);
        System.out.print(degenerate_8);}}

}
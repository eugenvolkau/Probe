import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
      long num = getNums();
     long facktr = factnum(num);
        System.out.println("factorial of a number " + facktr);
    }
    private static long factnum(long num){
        long itog=1;
                if(1<=num){
                    itog = num*factnum(num-1);
            return itog;}

        //System.out.println("factorial of a number " + itog);
    return itog;
        }
    private static long getNums() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Insert any nummer Pls from 1 ");
        if (sc.hasNextBigInteger()||(1<=sc.nextLong())) {
            return sc.nextLong();
        }   return getNums();
    }
}
//Используя рекурсию, написать метод вычисления факториала числа n (n!),
// вводимого с клавиатуры.
import foods.Snacks;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[] args)
    {
        Snacks[] ballast = Snacks.values();
        byte abc = getAbc();
        System.out.println("С Вас причитается €5.99 за  " + ballast[--abc]);
          System.out.println("Приятного аппетита!");
    }
    public static Byte getAbc() {
          int i = 0;
        for (Snacks ballast : Snacks.values())
             { System.out.println( ballast + "    жми    :  " + ++i);
             }
        System.out.println(" Из этого вкусного выбераем самый вкусный номер");
        Scanner scs = new Scanner(System.in);
        if (scs.hasNextByte()&&1<=i&&7>=i) {
            return scs.nextByte();
        }   return getAbc();
}
}
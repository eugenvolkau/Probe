public class Main {
    public static void main(String[] args)
    {

        boolean noPigOnRo = true;
        boolean isRoCl = true;
        boolean isEwac = false;
        boolean isOwner = true;
        boolean isNoEmpty = true;
        boolean isDrivOld = true;
       boolean isGoAut = (noPigOnRo&&isRoCl)&&(isEwac^(isOwner&&(isNoEmpty&&isDrivOld)));
String str = isGoAut?"Можете спокойно трогаться":"Вызываю полицию";
       System.out.println(str);
    }
}
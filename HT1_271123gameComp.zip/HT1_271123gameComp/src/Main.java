import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int compG = 10000;
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите число охваченных Вашей проблеммой друзей");
        int nfriend = sc.nextInt();
        int sumPres = 0;
        for (int i = 0; i <= nfriend; i++)
        {
            int apr = getPresent();
         sumPres = apr + sumPres;
        }
        System.out.println("Hello world!  Собрано   :" + sumPres);
    int delta = sumPres - compG;
        System.out.println("Осталось   :  " + delta);
    String alarm = delta<0 ? "Пойдите в казино. Поставьте на зеро. Может быть хватит на комп"
            : (0<=delta && delta<=2000) ? "Wow, cool. Можно повести друзей, кто конечно пожелает," +
            " на шиканый завтрак с кофием и пирожком в Макдональдсе" :  "Это похоже на бизнес. Время -" +
            " деньги. Никаких ресторанов!" ;
        System.out.println(alarm);
    }
    public static int getPresent()
    {
        Integer[] kupur = {50, 100, 200, 500};
        int kup = kupur[new Random().nextInt(4)];
        System.out.println(kup);
        return kup;
    }
}

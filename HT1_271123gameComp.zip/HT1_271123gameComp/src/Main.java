import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        int compG = 10000;
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите число охваченных Вашей проблеммой друзей");
        int nfriend = compG/50;
        int sumPres = 0;
        for (int i = 0; i <= nfriend; i++)
        {
            int apr = getPresent();
         sumPres = apr + sumPres;
            if(10000 < sumPres) {System.out.println("Hello world!  Собрано   :" + sumPres);
                System.out.println("Столько у Вас друзей  " +  i);
                int delta = sumPres - compG;

                System.out.println("Останется от покупки :  " + delta);
                System.out.println("Гуляем на все");
                break;
            }
        }

    }
    public static int getPresent()
    {
        Integer[] kupur = {50, 100, 200, 500};
        int kup = kupur[new Random().nextInt(4)];
        System.out.println(kup);
        return kup;
    }
}

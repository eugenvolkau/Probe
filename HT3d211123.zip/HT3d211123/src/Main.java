import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Indicate the year in which Our Elvis,");
        System.out.println("who is Presley lived or worked. Well, ");
        System.out.println("for example 1900");
        int years = sc.nextInt();
        String st1 = "Elvis wasn't born yet.";
        String st2 = "Elvis is alive!";
        String st3 = "Elvis is still more alive than anyone else alive!";
        String stras1 = years >= 1937 && years <= 1977 ? st2 : years > 1977 ? st3 : years < 1937 ? st1 : "";
        System.out.println(stras1);
    }
}
